﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace CitiesServer
{
    class RabbitMQClass
    {
        public RabbitMQClass()
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                MainChannel(channel);
            }
        }

        

        private void MainChannel(IModel channel)
        {
            channel.QueueDeclare(queue: "rpc_queue", durable: false,
                 exclusive: false, autoDelete: false, arguments: null);
            channel.BasicQos(0, 1, false);
            var consumer = new EventingBasicConsumer(channel);
            channel.BasicConsume(queue: "rpc_queue",
              autoAck: false, consumer: consumer);
            Console.WriteLine(" [x] Awaiting RPC requests");

            consumer.Received += (model, ea) =>
            {

                var body = ea.Body;
                var props = ea.BasicProperties;
                var replyProps = channel.CreateBasicProperties();
                replyProps.CorrelationId = props.CorrelationId;
                string mess = null;
                try
                {
                    var message = Encoding.UTF8.GetString(body);
                    mess = message;
                }
                catch (Exception e)
                {
                    Console.WriteLine(" [.] " + e.Message);
                }
                finally
                {
                    if (mess == "Name")
                    {
                        Init(mess, channel, props, replyProps, ea);
                    }
                    if (mess.Split(' ').Length==3)
                    {
                        SqlClass sql = new SqlClass();
                        sql.Add(mess);
                    }
                    else
                    {
                        DataForUser(mess, channel, props, replyProps, ea);
                    }
                }
            };
            Console.ReadLine();
        }
    
        private void Init(string mess, IModel channel,IBasicProperties props, IBasicProperties replyProps, BasicDeliverEventArgs ea)
        {
            SqlClass sql = new SqlClass { City = mess };
            var response = sql.Initializator();
            var responseBytes = Encoding.UTF8.GetBytes(response);
            channel.BasicPublish(exchange: "", routingKey: props.ReplyTo,
              basicProperties: replyProps, body: responseBytes);
            channel.BasicAck(deliveryTag: ea.DeliveryTag,
              multiple: false);
        }

        private void DataForUser(string mess, IModel channel, IBasicProperties props, IBasicProperties replyProps, BasicDeliverEventArgs ea)
        {
            Console.WriteLine(mess);
            SqlClass sql = new SqlClass { City = mess };
            var response = sql.DataUser();
            byte[] responseBytes = null;
            try
            {
                responseBytes = Encoding.UTF8.GetBytes(response);
            }
            catch (ArgumentException ae) { }
            finally
            {
                channel.BasicPublish(exchange: "", routingKey: props.ReplyTo,
              basicProperties: replyProps, body: responseBytes);
                channel.BasicAck(deliveryTag: ea.DeliveryTag,
                  multiple: false);
            }
        }
    }
}
