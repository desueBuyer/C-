﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace CitiesServer
{
    class Program
    {
        static void Main(string[] args)
        {
            RabbitMQClass rabbit = new RabbitMQClass();
            Console.ReadKey();
        }
    }
}
