﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace CitiesServer
{
    class SqlClass
    {
        public string City { get; set; }
        public string DataUser()
        {
            string response = null;
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                connection.Open();
                string command = String.Format("Select * from CityData where Name ='{0}'", City);
                SqlCommand comm = new SqlCommand(command, connection);
                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                    response = reader.GetValue(1).ToString() + " " + reader.GetValue(2).ToString();
                reader.Close();
                connection.Close();
            }
            return response;
        }

        public string Initializator()
        {
            string response = null;
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                connection.Open();
                string command = String.Format("Select Name from CityData");
                SqlCommand comm = new SqlCommand(command, connection);
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                        response += reader.GetValue(0).ToString() + " ";
                }
                reader.Close();
                connection.Close();
            }
            return response;
        }
        public void Add(string mess)
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                var add = mess.Split(' ');
                connection.Open();
                string command = String.Format("insert into CityData values('{0}', '{1}', {2}')", add[0], add[1], add[2]);
                SqlCommand comm = new SqlCommand(command, connection);
                connection.Close();
            }
        }
    }
}
