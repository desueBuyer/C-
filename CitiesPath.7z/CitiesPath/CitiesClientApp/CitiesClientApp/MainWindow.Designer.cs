﻿namespace CitiesClientApp
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstCity = new System.Windows.Forms.ComboBox();
            this.SecondCity = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ZeroLat = new System.Windows.Forms.Label();
            this.DesLat = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ZeroLong = new System.Windows.Forms.Label();
            this.DesLong = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Rez = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FirstCity
            // 
            this.FirstCity.FormattingEnabled = true;
            this.FirstCity.Location = new System.Drawing.Point(12, 45);
            this.FirstCity.Name = "FirstCity";
            this.FirstCity.Size = new System.Drawing.Size(121, 21);
            this.FirstCity.TabIndex = 0;
            // 
            // SecondCity
            // 
            this.SecondCity.FormattingEnabled = true;
            this.SecondCity.Location = new System.Drawing.Point(195, 45);
            this.SecondCity.Name = "SecondCity";
            this.SecondCity.Size = new System.Drawing.Size(121, 21);
            this.SecondCity.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Zero point";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Destination point";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Count";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Zero point latitude:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Destination point latitude:";
            // 
            // ZeroLat
            // 
            this.ZeroLat.AutoSize = true;
            this.ZeroLat.Location = new System.Drawing.Point(145, 111);
            this.ZeroLat.Name = "ZeroLat";
            this.ZeroLat.Size = new System.Drawing.Size(19, 13);
            this.ZeroLat.TabIndex = 8;
            this.ZeroLat.Text = "00";
            // 
            // DesLat
            // 
            this.DesLat.AutoSize = true;
            this.DesLat.Location = new System.Drawing.Point(145, 134);
            this.DesLat.Name = "DesLat";
            this.DesLat.Size = new System.Drawing.Size(19, 13);
            this.DesLat.TabIndex = 9;
            this.DesLat.Text = "00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(201, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Zero point longitude:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(201, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Destination point longitude:";
            // 
            // ZeroLong
            // 
            this.ZeroLong.AutoSize = true;
            this.ZeroLong.Location = new System.Drawing.Point(355, 111);
            this.ZeroLong.Name = "ZeroLong";
            this.ZeroLong.Size = new System.Drawing.Size(19, 13);
            this.ZeroLong.TabIndex = 12;
            this.ZeroLong.Text = "00";
            this.ZeroLong.Click += new System.EventHandler(this.Label7_Click);
            // 
            // DesLong
            // 
            this.DesLong.AutoSize = true;
            this.DesLong.Location = new System.Drawing.Point(355, 134);
            this.DesLong.Name = "DesLong";
            this.DesLong.Size = new System.Drawing.Size(19, 13);
            this.DesLong.TabIndex = 13;
            this.DesLong.Text = "00";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Rezult:";
            // 
            // Rez
            // 
            this.Rez.AutoSize = true;
            this.Rez.Location = new System.Drawing.Point(62, 167);
            this.Rez.Name = "Rez";
            this.Rez.Size = new System.Drawing.Size(19, 13);
            this.Rez.TabIndex = 15;
            this.Rez.Text = "00";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(0, -1);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(109, 20);
            this.Add.TabIndex = 16;
            this.Add.Text = "Add City";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Rez);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DesLong);
            this.Controls.Add(this.ZeroLong);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DesLat);
            this.Controls.Add(this.ZeroLat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SecondCity);
            this.Controls.Add(this.FirstCity);
            this.Name = "Form1";
            this.Text = "Path counter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox FirstCity;
        private System.Windows.Forms.ComboBox SecondCity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ZeroLat;
        private System.Windows.Forms.Label DesLat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label ZeroLong;
        private System.Windows.Forms.Label DesLong;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Rez;
        private System.Windows.Forms.Button Add;
    }
}

