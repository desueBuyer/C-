﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CitiesClientApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var names = InitList();
            foreach (var name in names)
            {
                if (!String.IsNullOrEmpty(name))
                {
                    FirstCity.Items.Add(name);
                    SecondCity.Items.Add(name);
                }
            }
        }

        public List<string> InitList()
        {
            RabbitMQ rabbitMQ = new RabbitMQ();
            var response = rabbitMQ.Call("Name").Split(' ');
            rabbitMQ.Close();
            return response.ToList();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            RabbitMQ rmq = new RabbitMQ();
            if (FirstCity.Text != null && SecondCity.Text != null)
            {
                string[] firstCD = rmq.Call(FirstCity.Text).Split(' ');
                string[] secondCD = rmq.Call(SecondCity.Text).Split(' ');

                ZeroLat.Text = firstCD[1];
                DesLat.Text = secondCD[1];
                ZeroLong.Text = firstCD[0];
                DesLong.Text = secondCD[0];
                Rez.Text = Counter(double.Parse(ZeroLat.Text), double.Parse(ZeroLong.Text), double.Parse(DesLat.Text), double.Parse(DesLong.Text)).ToString(); 
            }
        }

        private double Counter(double latFirst, double longFirst, double latSecond, double longSecond)
        {
            return 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(Math.Abs(latFirst - latSecond) / 2), 2) + Math.Cos(latFirst) * Math.Cos(latSecond) * Math.Pow(Math.Sin(Math.Abs(longFirst - longSecond) / 2), 2)))*6371;
        }
        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            Add add = new Add();
            add.Show();
        }
    }
}
