﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CitiesClientApp
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void Adder_Click(object sender, EventArgs e)
        {
            RabbitMQ rabbitMQ = new RabbitMQ();
            var mess = City.Text + " " + Longitude.Text + " " + Latitude.Text;
            rabbitMQ.Add(mess);
        }
    }
}
